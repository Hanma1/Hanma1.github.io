from django.apps import AppConfig


class Config(AppConfig):
    name = 'blog'
    verbose_name = 'Blog'

