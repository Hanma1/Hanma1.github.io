RE_URL = r'(?:ftp)|(?:https?)://[^\s\(\)\[\]]{3,}'
RE_ATUSER = r'@([\w\-_]+)(?:\b|\W)'
RE_HASHTAG = r'#([\w\-_]{2,})(?:\b|\W)'
